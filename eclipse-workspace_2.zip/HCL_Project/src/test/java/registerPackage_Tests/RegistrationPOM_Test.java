package registerPackage_Tests;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import registerPackage_Pages.RegistrationPOM_Page;

public class RegistrationPOM_Test {
	static String url = "https://demowebshop.tricentis.com/register";
	
	@Test
	public void registration_form() throws InterruptedException
	{
		System.setProperty("WebDriver.chrome.driver", "C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Project\\Driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		
		RegistrationPOM_Page rp_pom = new RegistrationPOM_Page(driver);
		Thread.sleep(2000);
		rp_pom.maleGender();
		rp_pom.firstName("Namit");
		rp_pom.lastName("KB");
		rp_pom.emailID("namitkb52145234@gmail.com");
		rp_pom.pass_word("Pass@123");
		rp_pom.confirm_password("Pass@123");
		rp_pom.register_Button();
		Thread.sleep(2000);
		driver.close();
	}
}

package registerPackage_Tests;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import registerPackage_Pages.LoginPOM_Page;
import registerPackage_Pages.RegistrationPOM_Page;

public class LoginPOM_Test {
	static String url = "https://demowebshop.tricentis.com/login";
	
	@Test
	public void login_form() throws InterruptedException
	{
		System.setProperty("WebDriver.chrome.driver", "C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Project\\Driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		
		RegistrationPOM_Page rp_pom = new RegistrationPOM_Page(driver);
		LoginPOM_Page login_pom = new LoginPOM_Page(driver);
		Thread.sleep(2000);
		
		rp_pom.emailID("namitkb51@gmail.com");
		rp_pom.pass_word("Pass@123");
		Thread.sleep(2000);
		
		login_pom.login_Button();
		Thread.sleep(2000);
		
		driver.close();
	}
}

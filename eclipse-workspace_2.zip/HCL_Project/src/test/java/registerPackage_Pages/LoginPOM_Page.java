package registerPackage_Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPOM_Page {
	
	WebDriver driver;
	
	@FindBy(id="Email") WebElement email;
	
	@FindBy(id="Password") WebElement password;
	
	@FindBy(how = How.XPATH, using = "//input[@value='Log in']") WebElement loginButton;
	
	public LoginPOM_Page(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void login_Button()
	{
		loginButton.click();
	}
}

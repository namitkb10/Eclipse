package registerPackage_Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegistrationPOM_Page {
	
	WebDriver driver;
	
	@FindBy(id="gender-male") WebElement genderMale;
	@FindBy(id="gender-female") WebElement genderFemale;
	
	@FindBy(id="FirstName") WebElement firstName;
	
	@FindBy(id="LastName") WebElement lastName;
	
	@FindBy(id="Email") WebElement email;
	
	@FindBy(id="Password") WebElement password;
	
	@FindBy(id="ConfirmPassword") WebElement confirmPassword;
	
	@FindBy(id="register-button") WebElement registerButton;
	
	public RegistrationPOM_Page(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void maleGender()
	{
		genderMale.click();
	}
	
	public void femaleGender()
	{
		genderFemale.click();
	}
	
	public void firstName(String fName)
	{
		firstName.sendKeys(fName);
	}
	
	public void lastName(String lName)
	{
		lastName.sendKeys(lName);
	}
	
	public void emailID(String email_id)
	{
		email.sendKeys(email_id);
	}
	
	public void pass_word(String pass)
	{
		password.sendKeys(pass);
	}
	
	public void confirm_password(String confirm_Pass)
	{
		confirmPassword.sendKeys(confirm_Pass);
	}
	
	public void register_Button()
	{
		registerButton.click();
	}
}

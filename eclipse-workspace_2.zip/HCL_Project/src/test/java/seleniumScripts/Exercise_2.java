package seleniumScripts;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Exercise_2 {

	static String url = "https://demowebshop.tricentis.com/";
	static String urlRegister = "https://demowebshop.tricentis.com/register";

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("WebDriver.chrome.driver", "C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Project\\Driver\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.navigate().to(url);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//a[text()='Register']")).click();
		Thread.sleep(2000);
		
		driver.navigate().back();
		if(url.equals(driver.getCurrentUrl()))
		{
			System.out.println("Back button/Home page URL verified");
		}
		else
		{
			System.out.println("Back button/Home page URL not verified");
		}
		Thread.sleep(2000);
		
		driver.navigate().forward();
		if(urlRegister.equals(driver.getCurrentUrl()))
		{
			System.out.println("Forward button/Register page URL verified");
		}
		else
		{
			System.out.println("Forward button/Register page URL not verified");
		}
		Thread.sleep(2000);
		
		driver.navigate().to(url);
		driver.navigate().refresh();
		Thread.sleep(2000);
		
		if(url.equals(driver.getCurrentUrl()))
		{
			System.out.println("Refresh button/Home page URL verified");
		}
		else
		{
			System.out.println("Refresh button/Home page URL not verified");
		}
		
		driver.close();
	}
}

package seleniumScripts;

import java.time.Duration;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Exercise_4 {

	static String url = "https://demowebshop.tricentis.com/";
	
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("WebDriver.chrome.driver", "C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Project\\Driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.navigate().to(url);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		List<WebElement> lstWebElement = driver.findElements(By.tagName("a"));
		System.out.println("No of links available: " + lstWebElement.size());
		Thread.sleep(2000);
		
		for (int i = 0; i < lstWebElement.size(); i++) {
			System.out.println(lstWebElement.get(i).getText() + "====" + lstWebElement.get(i).getAttribute("href"));
		}
		
		driver.close();
	}
}

package seleniumScripts;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Browser_Navigation {
	
	static String url = "https://demowebshop.tricentis.com/";
	static String urlLogin = "https://demowebshop.tricentis.com/login";

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		
		driver.navigate().to(url);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		
		Thread.sleep(2000);
		
		driver.navigate().to(urlLogin);
		
		String urlLogin1 = driver.getCurrentUrl();
		
		driver.navigate().back();
		
		System.out.println("Title of page is: " + driver.getTitle());
		
		System.out.println("Length of title is: " + driver.getTitle().length());
		
		if(driver.getCurrentUrl().equals(url))
		{
			System.out.println("Lauched URL is verified");
		}
		else
		{
			System.out.println("Lauched URL is not verified");
		}
			
		System.out.println("Page Source of page is: " + driver.getPageSource());
		
		System.out.println("Length of Page Source is: " + driver.getPageSource().length());
		
		driver.close();
	}
}

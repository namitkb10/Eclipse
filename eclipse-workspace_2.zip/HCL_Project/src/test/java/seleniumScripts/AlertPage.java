package seleniumScripts;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertPage {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://demo.automationtesting.in/Alerts.html");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//button[contains(text()='display an alert box:')]")).click();
		Alert alt = driver.switchTo().alert();
		String alertMessage = alt.getText();
		
		System.out.println("Alert Message: " + alertMessage);
		Thread.sleep(3000);
		alt.accept();
	}
}

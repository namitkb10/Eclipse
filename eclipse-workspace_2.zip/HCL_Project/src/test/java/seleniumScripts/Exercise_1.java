package seleniumScripts;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Exercise_1 {
	
	static String url = "https://demowebshop.tricentis.com/";

	public static void main(String[] args) {
		
		System.setProperty("WebDriver.chrome.driver", "C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Project\\Driver\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		
		System.out.println("Title of page is: " + driver.getTitle());
		
		System.out.println("Length of title is: " + driver.getTitle().length());
		
		if(driver.getCurrentUrl().equals(url))
		{
			System.out.println("Lauched URL is verified");
		}
		else
		{
			System.out.println("Lauched URL is not verified");
		}
			
		System.out.println("Page Source of page is: " + driver.getPageSource());
		
		System.out.println("Length of Page Source is: " + driver.getPageSource().length());
		
		driver.close();
	}
}

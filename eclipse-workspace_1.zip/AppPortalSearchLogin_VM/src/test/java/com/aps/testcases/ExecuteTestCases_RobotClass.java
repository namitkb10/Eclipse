/**
 * 
 */
package com.aps.testcases;

import java.io.IOException;
import java.util.Iterator;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * @author AppPortal
 *
 */
public class ExecuteTestCases_RobotClass{

	WebDriver driver;

	// @BeforeSuite
	@Test
	public void baseSetUp() throws InterruptedException, IOException, AWTException {

		WebDriverManager.chromedriver().setup();
		// ChromeOptions options = new ChromeOptions();
		// options.addArguments("--remote-allow-origins=*");
		// driver = new ChromeDriver(options);
		
		driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(30, TimeUnit.SECONDS);

		Thread.sleep(4000);
		
		// 1st URL
		String strURL = "http://10.75.204.205/esd";
		//Runtime.getRuntime().exec("C:\\AutoIT\\Login_App_Portal\\AutoIT_AppPortal_Login.exe");
		
		Thread.sleep(2000);
		driver.get(strURL);
		Thread.sleep(2000);
		
		Robot robot = new Robot();
		
		//typing text in text box one by one
		robot.keyPress(KeyEvent.VK_A);
		robot.keyRelease(KeyEvent.VK_P);
		Thread.sleep(500);
		for (int i = 0; i <=2; i++) {
			robot.keyPress(KeyEvent.VK_P);
			Thread.sleep(500);
		}
		robot.keyPress(KeyEvent.VK_O);
		robot.keyPress(KeyEvent.VK_R);
		robot.keyPress(KeyEvent.VK_T);
		robot.keyPress(KeyEvent.VK_A);
		robot.keyPress(KeyEvent.VK_L);
		robot.keyPress(KeyEvent.VK_BACK_SLASH);
		//======================================================
		robot.keyPress(KeyEvent.VK_A);
		robot.keyRelease(KeyEvent.VK_P);
		Thread.sleep(500);
		for (int i = 0; i <=2; i++) {
			robot.keyPress(KeyEvent.VK_P);
			Thread.sleep(500);
		}
		robot.keyPress(KeyEvent.VK_O);
		robot.keyPress(KeyEvent.VK_R);
		robot.keyPress(KeyEvent.VK_T);
		robot.keyPress(KeyEvent.VK_A);
		robot.keyPress(KeyEvent.VK_L);
		Thread.sleep(1000);
		
		robot.keyPress(KeyEvent.VK_TAB);
		
		robot.keyPress(KeyEvent.VK_SHIFT);
		robot.keyPress(KeyEvent.VK_F);
		robot.keyRelease(KeyEvent.VK_SHIFT);
		robot.keyPress(KeyEvent.VK_L);
		robot.keyPress(KeyEvent.VK_E);
		robot.keyPress(KeyEvent.VK_X);
		robot.keyPress(KeyEvent.VK_E);
		robot.keyPress(KeyEvent.VK_R);
		robot.keyPress(KeyEvent.VK_A);
		robot.keyRelease(KeyEvent.VK_A);
		//robot.keyPress(KeyEvent.VK_EXCLAMATION_MARK);
		robot.keyPress(KeyEvent.VK_SHIFT);
		robot.keyPress(KeyEvent.VK_1);
		robot.keyRelease(KeyEvent.VK_1);
		//Release SHIFT key to release upper case effect
		robot.keyRelease(KeyEvent.VK_SHIFT);
		
		Thread.sleep(2000);
		
		robot.keyPress(KeyEvent.VK_TAB);
		
		Thread.sleep(5000);
		
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		Thread.sleep(10000);

		String actualTitle = driver.getTitle();
		String expectedTitle = "Flexera Software App Portal";
		
		System.out.println("The page title is: " + actualTitle);
		
		Assert.assertEquals(actualTitle, expectedTitle);
		
		driver.findElement(By.id("Admin")).click();	
		Thread.sleep(5000);
		
		driver.findElement(By.id("tnSiteConfiguration")).click();
		Thread.sleep(5000);
		
		driver.findElement(By.id("nodeSettings")).click();
		Thread.sleep(5000);
		
		driver.findElement(By.id("RadPanelItem121")).click();
		Thread.sleep(5000);
		
		driver.switchTo().frame("RAD_SPLITTER_PANE_EXT_CONTENT_ctl00_cph1_topPane");
		Thread.sleep(5000);
		
		System.out.println("Switches to Frame");
		driver.findElement(By.xpath("//span[contains(text(),'Catalog Behavior')]")).click();
		
		WebElement weChkBoxSearchKeyword = driver.findElement(By.id("ctl00_cph1_keywordSearch"));
		WebElement weChkBoxSearchDescription = driver.findElement(By.id("ctl00_cph1_descriptionSearch"));
		
		for (int i = 0; i < 10; i++) {
			weChkBoxSearchKeyword.click();
			Thread.sleep(1000);
			weChkBoxSearchDescription.click();
			Thread.sleep(1000);
			weChkBoxSearchDescription.click();
		}
		
		driver.findElement(By.xpath("//a[@class='rtbWrap']")).click();
		
		Thread.sleep(5000);
		
		String savedMessage = driver.findElement(By.xpath("//span[text()='Settings Saved.']")).getText();
		
		String expectedMessage = "Settings Saved.";
		
		Assert.assertEquals(savedMessage, expectedMessage);
		
		
		
		/*
		 * if(!weChkBoxSearchKeyword.isSelected()) { weChkBoxSearchKeyword.click(); }
		 */
		
		
	}
}

/**
 * 
 */
package com.aps.testcases;

import java.io.IOException;
import java.util.Iterator;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * @author AppPortal
 *
 */
public class ExecuteTestCases_BrowserSetup {

	WebDriver driver;

	// @BeforeSuite
	@Test
	public void baseSetUp() throws InterruptedException, IOException, AWTException {
	
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		// options.addArguments("--remote-allow-origins=*");
		
		// Set the credentials for the authentication popup
		String username = "appportal\\appportal";
		String password = "Flexera!";

		options.addArguments("--user-data-dir=C:\\Users\\namitkumar.burnwal\\AppData\\Local\\Google\\Chrome\\User Data");

		options.addArguments("--auth-server-whitelist=*");

		//options.addArguments("--disable-popup-blocking");
		options.addArguments("--disable-notifications");
		options.addArguments("--start-maximized");
		// String strURL = "http://10.75.204.205/esd";
		driver = new ChromeDriver(options);

		driver.get("http://10.75.204.205/esd");

		Alert alert = driver.switchTo().alert();

		alert.sendKeys(username + Keys.TAB + password);
		alert.accept();

		String title = driver.getTitle();
		
		System.out.println("The page title is: " + title);
		
		Thread.sleep(5000);
	}
}

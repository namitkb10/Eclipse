/**
 * 
 */
package com.aps.testcases;

import java.io.IOException;
import java.util.Iterator;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * @author AppPortal
 *
 */
public class ExecuteTestCases {

	WebDriver driver;

	// @BeforeSuite
	@Test
	public void baseSetUp() throws InterruptedException, IOException, AWTException {

		ResourceBundle rb = ResourceBundle.getBundle("config");
		//String url = rb.getString("baseURL");
		String urlNew = rb.getString("baseURLNew");
		String browser = rb.getString("browser");

		System.out.println("URL is: " + urlNew);
		System.out.println("Browser is: " + browser);

		WebDriverManager.chromedriver().setup();
		// ChromeOptions options = new ChromeOptions();
		// options.addArguments("--remote-allow-origins=*");
		// driver = new ChromeDriver(options);
		
		// driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(30, TimeUnit.SECONDS);

		// driverobot.get("http://10.75.204.205/esd");
		// driverobot.navigate().to("http://10.75.204.205/esd");
		// driverobot.get("10.75.204.205/esd");
		// driverobot.get("http://appportal\\appportal:Flexera!@10.75.204.205/esd");
		// driverobot.navigate().to("http://appportal\\appportal:Flexera!@10.75.204.205/esd");
		Thread.sleep(4000);
		// driverobot.get("https://the-internet.herokuapp.com/basic_auth");
		//driverobot.get("https://admin:admin@the-internet.herokuapp.com/basic_auth");

		// driverobot.get("http://appportal\\appportal:Flexera!@10.75.204.205/esd");
		
		/*
		 * driverobot.switchTo().alert(); //Selenium-WebDriver Java Code for entering
		 * Username & Password as below:
		 * driverobot.findElement(By.id("userID")).sendKeys("userName");
		 * driverobot.findElement(By.id("password")).sendKeys("myPassword");
		 * driverobot.switchTo().alert().accept(); driverobot.switchTo().defaultContent();
		 */
		// String strUname = "appportal\\appportal";
		// String strPWD = "Flexera!";
		
		// 1st URL
		String strURL = "http://10.75.204.205/esd";
		//Runtime.getRuntime().exec("C:\\AutoIT\\Login_App_Portal\\AutoIT_AppPortal_Login.exe");
		
		// 2nd URL
		//String strURL = "https://the-internet.herokuapp.com/basic_auth";
		//Runtime.getRuntime().exec("C:\\AutoIT\\Login_App_Portal\\AutoIT_AppPortal_LoginBasic.exe");
		
		Thread.sleep(2000);
		// System.out.println("Created URL is: " + strURL);
		driver.get(strURL);
		Thread.sleep(2000);
		
		Robot robot = new Robot();
		
		//typing text in text box one by one
		robot.keyPress(KeyEvent.VK_A);
		robot.keyRelease(KeyEvent.VK_P);
		Thread.sleep(1000);
		for (int i = 0; i <=2; i++) {
			robot.keyPress(KeyEvent.VK_P);
			Thread.sleep(1000);
		}
		robot.keyPress(KeyEvent.VK_O);
		robot.keyPress(KeyEvent.VK_R);
		robot.keyPress(KeyEvent.VK_T);
		robot.keyPress(KeyEvent.VK_A);
		robot.keyPress(KeyEvent.VK_L);
		robot.keyPress(KeyEvent.VK_BACK_SLASH);
		//======================================================
		robot.keyPress(KeyEvent.VK_A);
		robot.keyRelease(KeyEvent.VK_P);
		Thread.sleep(1000);
		for (int i = 0; i <=2; i++) {
			robot.keyPress(KeyEvent.VK_P);
			Thread.sleep(1000);
		}
		robot.keyPress(KeyEvent.VK_O);
		robot.keyPress(KeyEvent.VK_R);
		robot.keyPress(KeyEvent.VK_T);
		robot.keyPress(KeyEvent.VK_A);
		robot.keyPress(KeyEvent.VK_L);
		Thread.sleep(1000);
		//robot.keyPress(KeyEvent.VK_EXCLAMATION_MARK);
		
		robot.keyPress(KeyEvent.VK_TAB);
		
		robot.keyPress(KeyEvent.VK_F);
		robot.keyPress(KeyEvent.VK_L);
		robot.keyPress(KeyEvent.VK_E);
		robot.keyPress(KeyEvent.VK_X);
		robot.keyPress(KeyEvent.VK_E);
		robot.keyPress(KeyEvent.VK_R);
		robot.keyPress(KeyEvent.VK_A);
		//robot.keyPress(KeyEvent.VK_EXCLAMATION_MARK);
		
		Thread.sleep(5000);
		
		robot.keyPress(KeyEvent.VK_TAB);
		
		Thread.sleep(2000);
		
		robot.keyPress(KeyEvent.VK_ENTER);
		 
		// robot.keyRelease(KeyEvent.VK_A);
		// robot.keyRelease(KeyEvent.VK_D);
		// robot.keyRelease(KeyEvent.VK_M);
		// robot.keyRelease(KeyEvent.VK_I);
		// robot.keyRelease(KeyEvent.VK_N);
		
		String title = driver.getTitle();
		
		System.out.println("The page title is: " + title);
		
		Thread.sleep(5000);
	}
}

package amazonShopping_Pages;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Set;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import ru.yandex.qatools.ashot.comparison.ImageDiff;
import ru.yandex.qatools.ashot.comparison.ImageDiffer;

public class AmazonShopping_Page {

	WebDriver driver;
	List<WebElement> menuItems;
	Actions act;
	JavascriptExecutor jse = (JavascriptExecutor)driver;
	String currentHandle;
	
	
	public AmazonShopping_Page(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.XPATH, using = "//a[text()='Mobiles']")
	WebElement mobileLink;

	@FindBy(how = How.XPATH, using = "//span[@class='nav-a-content']")
	List<WebElement> menuItemsList;

	@FindBy(how = How.XPATH, using = "//span[@class='nav-a-content' and contains(text(),'Laptops & Accessories')]")
	WebElement LaptopsAndAccessoriesLink;

	@FindBy(how = How.XPATH, using = "//a[text()='Dell']")
	WebElement dellCompanyLink;

	@FindBy(how = How.ID, using = "low-price")
	WebElement lowPriceTextBox;

	@FindBy(how = How.ID, using = "high-price")
	WebElement highPriceTextBox;

	@FindBy(how = How.XPATH, using = "//span[@class='a-button-inner']/input")
	WebElement goButton;

	@FindBy(how = How.ID, using = "twotabsearchtextbox")
	WebElement searchTextBox;

	@FindBy(how = How.XPATH, using = "//span[@class='a-size-medium-plus a-color-base a-text-bold' and text()='Results']")
	WebElement dispResult;

	@FindBy(how = How.XPATH, using = "//span[@class='a-size-medium a-color-base a-text-normal'])[1]")
	WebElement firstProductDisplayResult;

	@FindBy(how = How.XPATH, using = "//span[@class='a-price aok-align-center reinventPricePriceToPayMargin priceToPay']//span[@class='a-price-whole']")
	WebElement productPrice;

	@FindBy(how = How.XPATH, using = "//div[@id='contextualIngressPtLabel_deliveryShortLine']")
	WebElement clickDeliveryToLink;

	@FindBy(how = How.XPATH, using = "//input[@class='GLUX_Full_Width a-declarative']")
	WebElement enterPinCodeTextBox;

	@FindBy(how = How.XPATH, using = "//div[@id='GLUXZipInputSection']//input[@type='submit']")
	WebElement applyButton;

	@FindBy(how = How.XPATH, using = "//h2[text()='Customer reviews']")
	WebElement customerReviewText;

	@FindBy(how = How.XPATH, using = "//span[@class='a-size-medium a-color-base' and contains(text(),'out of 5')]")
	WebElement ratingNoteOutOf5Text;

	@FindBy(how = How.XPATH, using = "//h3[contains(text(),'Top reviews from India')]")
	WebElement topReviewsFromIndiaText;

	@FindBy(how = How.XPATH, using = "//a[@class='a-size-base a-link-normal review-title a-color-base review-title-content a-text-bold']/span[2]")
	List<WebElement> listOfCustomerTopReviewTitle;

	@FindBy(how = How.ID, using = "add-to-cart-button")
	WebElement addToCartButton;

	@FindBy(how = How.XPATH, using = "//div[@id='attachDisplayAddBaseAlert']//h4[text()='Added to Cart']")
	WebElement verifyAddedTocartText;

	public void clickOnMobileMenu(WebDriver driver2) {
		// TODO Auto-generated method stub
		mobileLink.click();
	}

	public void CountMenuItems() {
		menuItems = driver.findElements(By.xpath("//span[@class='nav-a-content']"));

		System.out.println("No of Menu Items: " + menuItems.size());
	}

	public void readsAllMenuItems() {
		for (WebElement element : menuItems) {
			System.out.println(element.getText());
		}

	}

	public void captureAndcompareScrrenShots() throws IOException {
		// Capture the screenshot and compare the screenshot with the expected
		// screenshot

		// ======================================================
		BufferedImage expectedImage = ImageIO.read(new File(
				"C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Usecase\\Expected_Screenshot\\Amazon_Mobiles_Click.png"));

		// capture screen shot
		TakesScreenshot tss = (TakesScreenshot) driver;
		File srcFile = tss.getScreenshotAs(OutputType.FILE);
		File dstFile = new File(
				"C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Usecase\\Actual_Screenshot\\Amazon_Mobiles_Click_Actual.png");
		FileUtils.copyFile(srcFile, dstFile);

		BufferedImage actualImage = ImageIO.read(dstFile);

		// Compare the Images
		ImageDiffer imageDiffer = new ImageDiffer();
		ImageDiff imageDiff = imageDiffer.makeDiff(expectedImage, actualImage);

		System.out.println();
		System.out.println();

		if (imageDiff.hasDiff() == true) {
			System.out.println("Screen Shots are not same");
			System.out.println("Images Not Matching");
			// Assert.fail("Images Not Matching");
		} else {
			System.out.println("Screen Shots are same");
			System.out.println("Images Matched");
			Assert.assertEquals(expectedImage, actualImage);
		}
	}

	public void mouseHoverAndClickOnDellBrand() throws InterruptedException {
		act = new Actions(driver);
		act.moveToElement(driver.findElement(By.xpath("//span[@class='nav-a-content' and contains(text(),'Laptops & Accessories')]"))).build().perform();
		
		WebElement laptopBrand = driver.findElement(By.xpath("//a[text()='Dell']"));
		
		act.moveToElement(laptopBrand).build().perform();
		Thread.sleep(2000);
		laptopBrand.click();
		
	}

	public void updatePriceRange() {
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,500)", "");
		
		driver.findElement(By.id("low-price")).sendKeys("40000");
		driver.findElement(By.id("high-price")).sendKeys("100000");
		driver.findElement(By.xpath("//span[@class='a-button-inner']/input")).click();
	}

	public void searchForGamingLaptop() throws InterruptedException {
		jse.executeScript("window.scrollBy(0,-500)", "");
		
		// driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("Gaming Laptop");
		// driver.findElement(By.xpath("//input[@id='nav-search-submit-button']")).click();
		currentHandle= driver.getWindowHandle();
		System.out.println("Current Window: " + currentHandle);
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Gaming Laptop", Keys.ENTER);
		
		jse.executeScript("window.scrollBy(0,300)", "");
		
		String displayResult = driver.findElement(By.xpath("//span[@class='a-size-medium-plus a-color-base a-text-bold' and text()='Results']")).getText();
		Assert.assertEquals(displayResult, "Results");
		
		
	}

	public void clickOnFirstSearchResult() throws InterruptedException {
		driver.findElement(By.xpath("(//span[@class='a-size-medium a-color-base a-text-normal'])[1]")).click();
		Thread.sleep(3000);
		Set<String> handles=driver.getWindowHandles();
		for(String actual: handles)
		{
			System.out.println(actual);
			if(!actual.equalsIgnoreCase(currentHandle)) {
				//Switch to the opened tab
				driver.switchTo().window(actual);
			}
		}
		
		jse.executeScript("window.scrollBy(0,100)", "");
		System.out.println("Current Title: "+ driver.getTitle());
		
	}

	public void verifyProductPrice() throws InterruptedException {
		
		Thread.sleep(6000);
		String strPrice = driver.findElement(By.xpath("//span[@class='a-price aok-align-center reinventPricePriceToPayMargin priceToPay']//span[@class='a-price-whole']")).getText();
		System.out.println(strPrice);
		strPrice.replace(",", "");
		System.out.println(strPrice);
	}

	public void updateDeliveryLocationPincode() {
		act.moveToElement(driver.findElement(By.xpath("//div[@id='contextualIngressPtLabel_deliveryShortLine']"))).build().perform();

		driver.findElement(By.xpath("//div[@id='contextualIngressPtLabel_deliveryShortLine']")).click();
		  
		driver.findElement(By.xpath("//input[@class='GLUX_Full_Width a-declarative']")).sendKeys("826001");
		driver.findElement(By.xpath("//div[@id='GLUXZipInputSection']//input[@type='submit']")).click();
	
	}

	public void CaptureAverageRatings() throws InterruptedException {
		for (int i = 0; i < 275; i++) {
			jse.executeScript("window.scrollBy(0,40)", "");
			Thread.sleep(1);
		}
		
		Thread.sleep(3000);
		act.moveToElement(driver.findElement(By.xpath("//h2[text()='Customer reviews']")));
		String ratingNote = driver.findElement(By.xpath("//span[@class='a-size-medium a-color-base' and contains(text(),'out of 5')]")).getText();
		System.out.println("Ratings: " + ratingNote);
	}

	public void readTopCustomerReviews() {
		act.moveToElement(driver.findElement(By.xpath("//h3[contains(text(),'Top reviews from India')]")));
		List<WebElement> customerTopReviewTitle = driver.findElements(By.xpath("//a[@class='a-size-base a-link-normal review-title a-color-base review-title-content a-text-bold']/span[2]"));
		System.out.println("Top review counts: " + customerTopReviewTitle.size());
		
		for (WebElement reviewTitle : customerTopReviewTitle) {
		    System.out.println(reviewTitle.getText());
		}
	}

	public void AddProductToCartButton() throws InterruptedException {
		jse.executeScript("window.scrollBy(0,-15000)", "");
		jse.executeScript("window.scrollBy(0,500)", "");
		
		driver.findElement(By.xpath("//input[@id='add-to-cart-button']")).click();
		Thread.sleep(5000);
		
	}

	public void VerifyAddedProductIntoCart() {
		String verifyAddedTocart = driver.findElement(By.xpath("//div[@id='attachDisplayAddBaseAlert']//h4[text()='Added to Cart']")).getText(); 
		Assert.assertEquals(verifyAddedTocart,"Added to Cart");
	}
}

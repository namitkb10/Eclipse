package amazonShopping_Tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

public class BaseClass {
	
	public static WebDriver driver;

	@Parameters("browser")
	@BeforeClass
	public void setup(String br) {
		if (br.equals("chrome")) {
			// System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\Amazon_Usecases\\Driver\\chromedriver.exe");
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\Amazon_Usecases\\Driver\\chromedriver.exe");
			driver = new ChromeDriver();
		} else if (br.equals("edge")) {
			System.setProperty("webdriver.chrome.driver", "Update edge driver path");
			driver = new EdgeDriver();
		}
	}
	
	@AfterClass
	public void tearDown()
	{
		// driver.quit();
	}

}

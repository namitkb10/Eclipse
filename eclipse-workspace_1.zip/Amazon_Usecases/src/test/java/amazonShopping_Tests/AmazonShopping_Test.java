package amazonShopping_Tests;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import amazonShopping_Pages.AmazonShopping_Page;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AmazonShopping_Test extends BaseClass {

	// WebDriver driver;
	
	//to perform Scroll on application using Selenium
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	Actions act = new Actions(driver);
	
	AmazonShopping_Page asp = new AmazonShopping_Page(driver);
	
	@Given("User launches the browser")
	public void user_launches_the_browser() {
		
	}

	@When("user opens the given URL {string}")
	public void user_opens_the_given_url(String string) {
		driver.get("https://www.amazon.in/"); // Launch URL
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		Assert.assertEquals(driver.getTitle(), "Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in");
	}

	@When("User click on Mobile menu")
	public void user_click_on_mobile_menu() {
	    asp.clickOnMobileMenu(driver);
	}

	@Then("Count and reads all the menu options")
	public void count_and_reads_all_the_menu_options() {
	    asp.CountMenuItems();
	    asp.readsAllMenuItems();
	}

	@Then("Then Capture the screenshot and compare")
	public void then_capture_the_screenshot_and_compare() throws IOException {
	    asp.captureAndcompareScrrenShots();
	}

	@When("Hover mouse on {string} and shop by brand Dell")
	public void hover_mouse_on_and_shop_by_brand_dell(String string) throws InterruptedException {
	    asp.mouseHoverAndClickOnDellBrand();
	}

	@Then("Update price range minimum {int} to max {int}")
	public void update_price_range_minimum_to_max(Integer int1, Integer int2) {
	    asp.updatePriceRange();
	}

	@When("Search for {string}")
	public void search_for(String string) throws InterruptedException {
	    asp.searchForGamingLaptop();
	}

	@Then("Click on first search result")
	public void click_on_first_search_result() throws InterruptedException {
	    asp.clickOnFirstSearchResult();
	}

	@Then("Verify product amount is greater than zero")
	public void verify_product_amount_is_greater_than_zero() throws InterruptedException {
	    asp.verifyProductPrice();
	}

	@Then("Update delivery location pin code")
	public void update_delivery_location_pin_code() {
	    asp.updateDeliveryLocationPincode();
	}

	@Then("Capture average rating of the product")
	public void capture_average_rating_of_the_product() throws InterruptedException {
	    asp.CaptureAverageRatings();
	}

	@Then("Read Top customer reviews from India and update in excel sheet")
	public void read_top_customer_reviews_from_india_and_update_in_excel_sheet() {
	    asp.readTopCustomerReviews();
	}

	@When("Add Item to cart")
	public void add_item_to_cart() throws InterruptedException {
	    asp.AddProductToCartButton();
	}

	@Then("verify items added to the cart")
	public void verify_items_added_to_the_cart() {
	    asp.VerifyAddedProductIntoCart();
	}
}

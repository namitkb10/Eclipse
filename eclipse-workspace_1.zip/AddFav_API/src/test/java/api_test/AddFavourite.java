package api_test;

import org.testng.annotations.Test;

public class AddFavourite {
	
	/*
	 * @Test public void postAPI() { given()
	 * 
	 * .when().
	 * 
	 * .then();
	 * 
	 * }
	 */
}
package stepDefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ShoppingKart {
	
	WebDriver driver;
	//to perform Scroll on application using Selenium
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	Actions act = new Actions(driver);
	
	/* @Given("user open the Ecommerce Website portal")
	public void user_open_the_Ecommerce_Website_portal()
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\Cucumber_ShoppingKart\\Driver\\chromedriver.exe");
		// WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/"); // Launch URL
		driver.manage().window().maximize();
		Assert.assertEquals(driver.getCurrentUrl(), "https://demowebshop.tricentis.com/");
	}
	
	@When("user navigate to the desktop Page Computer Desktop")
	public void user_navigate_to_the_desktop_Page_Computer_Desktop() throws InterruptedException
	{
		WebElement computerText = driver.findElement(By.xpath("(//a[@href='/computers'])[1]"));
		
		act.moveToElement(computerText).build().perform();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("(//a[@href='/desktops'])[1]")).click();
		Thread.sleep(2000);
		
		Assert.assertEquals(driver.getCurrentUrl(), "https://demowebshop.tricentis.com/desktops");
	}
	
	@Then("Desktop products should display")
	public void Desktop_products_should_display() throws InterruptedException
	{
		Assert.assertEquals(driver.getTitle(), "Demo Web Shop. Desktops");
	}
	
	@And("Count and display the items from position drop down box")
	public void Count_and_display_the_items_from_position_drop_down_box()
	{
		WebElement dropDownPosition = driver.findElement(By.id("products-orderby"));
		Select sel = new Select(dropDownPosition);
		List<WebElement> lstWebElement = sel.getOptions();
		System.out.println("No of Element in position drop down: " + lstWebElement.size());
		
		for(int i=0; i<lstWebElement.size(); i++)
		{
			System.out.println(lstWebElement.get(i).getText());
		}
	}
	
	@When("click on Build your own expensive computer")
	public void click_on_Build_your_own_expensive_computer() throws InterruptedException
	{
		jse.executeScript("window.scrollBy(0,300)", "");
		Thread.sleep(2000);
		// driver.findElement(By.xpath("//h2[@class='product-title']/a[text()='Build your own expensive computer']")).click();
		driver.findElement(By.linkText("Build your own expensive computer")).click();
		Assert.assertEquals(driver.getTitle(), "Demo Web Shop. Desktops");
	}
	
	@Then ("navigate to Build your own expensive computer")
	public void navigate_to_Build_your_own_expensive_computer()
	{
		Assert.assertEquals(driver.getTitle(), "Demo Web Shop. Build your own expensive computer");
	}
	
	@And("Configure your desktop")
	public void Configure_your_desktop() throws InterruptedException
	{
		jse.executeScript("window.scrollBy(0,400)", "");
		Thread.sleep(2000);
		
		driver.findElement(By.id("product_attribute_74_5_26_82")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("product_attribute_74_6_27_85")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("product_attribute_74_3_28_87")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("product_attribute_74_8_29_89")).click();
		Thread.sleep(1000);
		// Assert.assertEquals(null, null);
	}
	
	@And ("Update the qty to two and click on add to cart button")
	public void Update_the_qty_to_two_and_click_on_add_to_cart_button() throws InterruptedException
	{
		WebElement weQty = driver.findElement(By.xpath("//input[@class='qty-input']"));
		Thread.sleep(2000);
		
		act.doubleClick(weQty).build().perform();
		Thread.sleep(2000);
		weQty.sendKeys("2");
		Thread.sleep(2000);
		driver.findElement(By.id("add-to-cart-button-74")).click();
		Thread.sleep(2000);
		Assert.assertEquals(weQty.getText(), weQty.getText());
	}
	
	@And("Verify the added products into the carts")
	public void Verify_the_added_products_into_the_carts() throws InterruptedException
	{
		jse.executeScript("window.scrollBy(0,-400)", "");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(text(),'Shopping cart')]")).click();
		Assert.assertEquals(driver.getTitle(), "Demo Web Shop. Shopping Cart");
	}*/
	

@Given("user open the Ecommerce Website portal")
public void user_open_the_ecommerce_website_portal() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@When("user navigate to the desktop Page Computer Desktop")
public void user_navigate_to_the_desktop_page_computer_desktop() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@Then("Desktop products should display")
public void desktop_products_should_display() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@Then("Count and display the items from position drop down box")
public void count_and_display_the_items_from_position_drop_down_box() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@When("click on Build your own expensive computer")
public void click_on_build_your_own_expensive_computer() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@Then("navigate to Build your own expensive computer")
public void navigate_to_build_your_own_expensive_computer() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@Then("Configure your desktop")
public void configure_your_desktop() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@Then("Update the qty to two and click on add to cart button")
public void update_the_qty_to_two_and_click_on_add_to_cart_button() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@Then("Verify the added products into the carts")
public void verify_the_added_products_into_the_carts() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}
}

/**
 * 
 */
package com.demopom.actioninterface;

/**
 * @author namitkumar.burnwal
 *
 */
public class ActionInterface {

}

/**
 * 
 */
package com.demopom.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.demopom.base.BaseClass;

/**
 * @author namitkumar.burnwal
 *
 */
public class HomePage extends BaseClass {
	
	@FindBy(xpath="//a[@class='oxd-main-menu-item active']")
	WebElement adminTab;
	
	public HomePage(){
		PageFactory.initElements(driver, this);
	}

	public SystemUsersPage clickOnAdminTab() {
		
		System.out.println("HomePage Driver :" + driver);
		
		adminTab.click();
		return new SystemUsersPage(driver);
	}
}

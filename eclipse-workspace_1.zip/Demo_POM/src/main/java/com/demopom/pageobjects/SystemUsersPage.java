/**
 * 
 */
package com.demopom.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.demopom.base.BaseClass;

/**
 * @author namitkumar.burnwal
 *
 */
public class SystemUsersPage extends BaseClass {

	public SystemUsersPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
}

/**
 * 
 */
package com.demopom.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.demopom.base.BaseClass;

/**
 * @author namitkumar.burnwal
 *
 */
public class LoginPage extends BaseClass {
	
	@FindBy(xpath="//div[@class='orangehrm-login-branding']")
	WebElement logo;
	
	@FindBy(name="username")
	WebElement enterUserName;
	
	@FindBy(name="password")
	WebElement enterPassword;
	
	@FindBy(xpath="//button[@type='submit']")
	WebElement buttonLogin;
	
	public LoginPage() {
		PageFactory.initElements(driver, this);
	}
	
	public boolean validateLogo() throws InterruptedException
	{
		Thread.sleep(5000);
		return logo.isDisplayed();
	}
	
	public HomePage userLogin() throws InterruptedException
	{
		Thread.sleep(5000);
		enterUserName.sendKeys("Admin");
		enterPassword.sendKeys("admin123");
		Thread.sleep(3000);
		buttonLogin.click();
		System.out.println("LoginPage Driver :" + driver);
		return new HomePage();
		
	}
}

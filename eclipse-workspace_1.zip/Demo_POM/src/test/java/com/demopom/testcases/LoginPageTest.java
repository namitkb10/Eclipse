/**
 * 
 */
package com.demopom.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.demopom.base.BaseClass;
import com.demopom.pageobjects.HomePage;

/**
 * @author namitkumar.burnwal
 *
 */
public class LoginPageTest extends BaseClass {
	
	// LoginPage loginPage;
	HomePage homePage = new HomePage();
	
	@Test
	public void validateLogo() throws InterruptedException
	{
		Thread.sleep(5000);
		boolean result = loginPage.validateLogo();
		Assert.assertTrue(result);
	}
	
	@Test
	public void validateLogin() throws InterruptedException
	{
		Thread.sleep(5000);
		homePage = loginPage.userLogin();
		String expectedResult = "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index";
		System.out.println("LoginPageTest Driver :" + driver);
		String actualResult = driver.getCurrentUrl();
		
		Assert.assertEquals(actualResult, expectedResult);
		
	}
}

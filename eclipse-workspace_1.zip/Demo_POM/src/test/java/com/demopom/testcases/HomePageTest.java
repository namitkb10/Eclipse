/**
 * 
 */
package com.demopom.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.demopom.base.BaseClass;
import com.demopom.pageobjects.HomePage;

/**
 * @author namitkumar.burnwal
 *
 */
public class HomePageTest extends BaseClass{
	
	// LoginPage loginPage;
	HomePage homePage = new HomePage();
	
	@Test
	public void adminTabTest() throws InterruptedException
	{
		
		System.out.println("HomePageTest Driver :" + driver);
		
		Thread.sleep(5000);
		loginPage.userLogin();
		Thread.sleep(5000);
		homePage.clickOnAdminTab();
		
		String expectedResult = "https://opensource-demo.orangehrmlive.com/web/index.php/admin/viewSystemUsers";
		String actualResult = driver.getCurrentUrl();
		Thread.sleep(5000);
		Assert.assertEquals(actualResult, expectedResult);
	}
}

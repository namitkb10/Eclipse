package com.pgdemo.testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.pgdemo.pageobject.accountCreationDetails;
import com.pgdemo.pageobject.indexPage;
import com.pgdemo.pageobject.myAccountPage;
import com.pgdemo.pageobject.registeredUserAccount;
import com.pgdemo.base.BaseClass;

public class TC_MyAccountPageTest extends BaseClass {

	@Test(enabled=false)
	public void verifyRegistrationAndLogin()
	{
		logger.info("***************TestCase Verify Registration and Login starts*****************"); 

		//============================================================================
		indexPage pg = new indexPage(driver);

		pg.clickOnSignIn();
		logger.info("Clicked on sign in link");

		myAccountPage myAcpg = new myAccountPage(driver);
		myAcpg.enterCreateEmailAddress("namitkb21@gmail.com");
		logger.info("Email address entered in create account section.");

		myAcpg.clickSubmitCreate();

		logger.info("clicked on create an account button");

		//============================================================================
		accountCreationDetails accCreationPg = new accountCreationDetails(driver);

		accCreationPg.selectTitleMr();
		accCreationPg.enterCustomerFirstName("Namit");
		accCreationPg.enterCustomerLastName("KB");
		accCreationPg.enterCustomerEmail("namitkb21@gmail.com");
		accCreationPg.enterPassword("Artelus@21");
		
		// accCreationPg.enterAddressFirstName("Namit");
		// accCreationPg.enterAddressLastName("KB");
		// accCreationPg.enterAddress("123/45, Bank More, Dhanbad");

		// accCreationPg.enterCity("Dhanbad");
		// accCreationPg.selectState("Alabama");

		// accCreationPg.enterPostcode("00000");
		// accCreationPg.selectCountry("United States");
		// accCreationPg.enterMobilePhone("9891778192");
		// accCreationPg.enterAlias("Home");

		logger.info("entered user details on account creation page.");

		accCreationPg.clickOnRegister();
		logger.info("clicked on Register button");

		//============================================================================
		registeredUserAccount regUser = new registeredUserAccount(driver);
		String userName = regUser.getUserName();

		Assert.assertEquals("Namit KB", userName);

		logger.info("***************TestCase Verify Registration and Login ends*****************"); 
	}

	@Test(enabled=false)
	public void VerifyLogin() throws IOException 
	{

		logger.info("***************TestCase Verify Login starts*****************"); 

		indexPage pg = new indexPage(driver);

		pg.clickOnSignIn();
		logger.info("Clicked on sign in link");

		myAccountPage myAcpg = new myAccountPage(driver);

		myAcpg.enterEmailAddress("namitkb21@gmail.com");
		logger.info("Entered email address");

		myAcpg.enterPassword("Artelus@21");
		logger.info("Entered password");

		myAcpg.clickSignIn();
		logger.info("Clicked on sign in link..");

		registeredUserAccount regUser = new registeredUserAccount(driver);
		String userName = regUser.getUserName();

		if(userName.equals("Namit KB"))
		{
			logger.info("VerifyLogin - Passed");
			regUser.clickOnSignOut();
			Assert.assertTrue(true);
		}
		else
		{
			logger.info("VerifyLogin - Failed");
			captureScreenShot(driver,"VerifyLogin");
			Assert.assertTrue(false);
		}
		logger.info("***************TestCase Verify Login ends*****************"); 
	}

	@Test(enabled=true)
	public void VerifySignOut() throws IOException 
	{

		logger.info("***************TestCase Verify Sign out starts*****************"); 

		indexPage pg = new indexPage(driver);

		pg.clickOnSignIn();
		logger.info("Clicked on sign in link");

		myAccountPage myAcpg = new myAccountPage(driver);

		myAcpg.enterEmailAddress("namitkb21@gmail.com");
		logger.info("Entered email address");

		myAcpg.enterPassword("Artelus@21");
		logger.info("Entered password");

		myAcpg.clickSignIn();
		logger.info("Clicked on sign in link..");

		registeredUserAccount regUser = new registeredUserAccount(driver);
		regUser.clickOnSignOut();

		if(pg.getPageTitle().equals("Login - My Store"))
		{
			logger.info("VerifySignOut - Passed");
			Assert.assertTrue(true);
		}
		else
		{
			logger.info("VerifySignOut - Failed");
			captureScreenShot(driver,"VerifySignOut");
			Assert.assertTrue(false);
		}
		logger.info("***************TestCase Verify Sign out ends*****************"); 
	}
}

/**
 * 
 */
package com.pgdemo.testcases_1;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.pgdemo.base.BaseClass;
//import com.pgdemo.dataprovider.DataProviders;
//import com.pgdemo.pageobjects.HomePage;
// import com.pgdemo.pageobject_1.indexPage;
import com.pgdemo.pageobject_1.HomePage;
import com.pgdemo.pageobject_1.LoginPage;

/**
 * @author Namit
 *
 */
public class LoginPageTest extends BaseClass {
	// private indexPage pg;
	private LoginPage loginPage = new LoginPage(driver);
	private HomePage homePage = new HomePage(driver);
	
	/*
	 * @Parameters("browser")
	 * 
	 * @BeforeMethod(groups = {"Smoke","Sanity","Regression"}) public void
	 * setup(String browser) { launchApp(browser); }
	 * 
	 * @AfterMethod(groups = {"Smoke","Sanity","Regression"}) public void tearDown()
	 * { getDriver().quit(); }
	 */
	@Test
	public void loginTest() throws Throwable {
		loginPage.login("namitkb22@gmail.com", "Artelus@22");
		// pg = new indexPage(driver);
		//Log.info("user is going to click on SignIn");
		//loginPage=pg.clickOnSignIn();
		//Log.info("Enter Username and Password");
	    //homePage=loginPage.login(prop.getProperty("username"), prop.getProperty("password"));
		// homePage=loginPage.login("namitkb22@gmail.com", "Artelus@22", homePage);
		
	    String actualURL=homePage.getCurrURL();
	    String expectedURL="http://automationpractice.com/index.php?controller=my-account";
	    // Log.info("Verifying if user is able to login");
	    Assert.assertEquals(actualURL, expectedURL);
	    // Log.info("Login is Sucess");
	    // Log.endTestCase("loginTest");
	}

}

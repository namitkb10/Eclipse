/**
 * 
 */
package com.pgdemo.pageobject_1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.pgdemo.actiondriver.Action;
import com.pgdemo.base.BaseClass;

/**
 * @author Namit
 *
 */
public class HomePage extends BaseClass {
	
	// 1. create object of webDriver
		WebDriver ldriver;

		// Constructor
		public HomePage(WebDriver rdriver) {
			ldriver = rdriver;
			PageFactory.initElements(rdriver, this);
		}
	
	Action action= new Action();
	
	@FindBy(xpath="//span[text()='My wishlists']")
	private WebElement myWishList;
	
	@FindBy(xpath = "//span[text()='Order history and details']")
	private WebElement orderHistory;
	
	public HomePage() {
		PageFactory.initElements(ldriver, this);
	}

	
	public boolean validateMyWishList() throws Throwable {
		return action.isDisplayed(ldriver, myWishList);
	}
	
	public boolean validateOrderHistory() throws Throwable {
		return action.isDisplayed(ldriver, orderHistory);
	}
	
	public String getCurrURL() throws Throwable {
		String homePageURL=action.getCurrentURL(ldriver);
		return homePageURL;
	}
}

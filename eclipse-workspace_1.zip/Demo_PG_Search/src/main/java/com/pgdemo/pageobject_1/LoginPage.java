/**
 * 
 */
package com.pgdemo.pageobject_1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.pgdemo.actiondriver.Action;
import com.pgdemo.base.BaseClass;

/**
 * @author Namit
 * 
 */
public class LoginPage extends BaseClass {

	// 1. create object of webDriver
	WebDriver ldriver;

	// constructor
	public LoginPage(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	Action action = new Action();

	@FindBy(id = "email")
	private WebElement userName;

	@FindBy(id = "passwd")
	private WebElement password;

	@FindBy(id = "SubmitLogin")
	private WebElement signInBtn;

	@FindBy(name = "email_create")
	private WebElement emailForNewAccount;

	@FindBy(name = "SubmitCreate")
	private WebElement createNewAccountBtn;

	public void login(String uname, String pswd) throws Throwable {
		indexPage ip= new indexPage(ldriver);
		ip.clickOnSignIn();
		action.scrollByVisibilityOfElement(ldriver, userName);
		action.type(userName, uname);
		action.type(password, pswd);
		action.JSClick(driver, signInBtn);
	}

	/*
	 * public AddressPage login(String uname, String pswd, AddressPage addressPage)
	 * throws Throwable { action.scrollByVisibilityOfElement(driver, userName);
	 * action.type(userName, uname); action.type(password, pswd);
	 * action.click(driver, signInBtn); Thread.sleep(2000); addressPage=new
	 * AddressPage(); return addressPage; }
	 */

	/*
	 * public AccountCreationPage createNewAccount(String newEmail) throws Throwable
	 * { action.type(emailForNewAccount, newEmail); action.click(getDriver(),
	 * createNewAccountBtn); return new AccountCreationPage(); }
	 */
}

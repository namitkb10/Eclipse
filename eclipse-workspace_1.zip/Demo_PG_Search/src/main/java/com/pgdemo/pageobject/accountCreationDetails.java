package com.pgdemo.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class accountCreationDetails {

	// 1. create object of webDriver
	WebDriver ldriver;

	// Constructor
	public accountCreationDetails(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	// identify webElements
	@FindBy(id = "id_gender1") // Title-Mr
	WebElement titleMrs;

	@FindBy(id = "id_gender2") // Title-Mrs
	WebElement titleMr;

	@FindBy(id = "customer_firstname")
	WebElement custfirstName;

	@FindBy(id = "customer_lastname")
	WebElement custlastName;

	@FindBy(id = "email")
	WebElement custEmail;

	@FindBy(id = "passwd")
	WebElement custPassword;

	@FindBy(id = "submitAccount")
	WebElement register;
	// ==========================================================
	
	public void selectTitleMr() {
		titleMr.click();
	}

	public void selectTitleMrs()
	{
		titleMrs.click();
	}

	public void enterCustomerFirstName(String fname) {
		custfirstName.sendKeys(fname);
	}

	public void enterCustomerLastName(String lname) {
		custlastName.sendKeys(lname);
	}

	public void enterCustomerEmail(String email) {
		custEmail.clear();
		custEmail.sendKeys(email);
	}

	public void enterPassword(String pwd) {
		custPassword.clear();
		custPassword.sendKeys(pwd);
	}

	public void clickOnRegister() {
		register.click();
	}
}

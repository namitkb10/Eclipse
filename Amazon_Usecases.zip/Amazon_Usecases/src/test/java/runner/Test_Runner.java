package runner;

import org.junit.runner.RunWith;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions
(features="Features", glue={"amazonShopping_Tests"}, monochrome= true,
plugin= {"pretty","html:htmlrepo/test-output.html"}
)
public class Test_Runner {
	
}



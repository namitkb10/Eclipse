/**
 * 
 */
package com.webautomation.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.webautomation.actiondriver.Action;
import com.webautomation.base.BaseClass;

/**
 * @author namitkumar.burnwal
 *
 */
public class ZPracticePage extends BaseClass  {
	
	Action action = new Action();
	
	// Radio Button Example
	@FindBy(xpath = "//input[@value='radio1']")
	private WebElement radioButton1;
	
	@FindBy(xpath = "//div[@id='radio-btn-example']/fieldset/label[2]")
	private WebElement radioButton2;
	
	@FindBy(xpath = "//div[@id='radio-btn-example']/fieldset/label[3]")
	private WebElement radioButton3;
	
	// Suggestion Class Example
	@FindBy(xpath = "//input[@id='autocomplete']")
	private WebElement autoCompleteTextBox;
	
	// Dropdown Example
	@FindBy(xpath = "//option[text()='Option1']")
	private WebElement dropDownOption1;
	
	@FindBy(xpath = "//option[text()='Option2']")
	private WebElement dropDownOption2;
	
	@FindBy(xpath = "//option[text()='Option3']")
	private WebElement dropDownOption3;
	
	@FindBy(id="dropdown-class-example")
	private WebElement dropDownList1;
	
	// Checkbox Example
	@FindBy(id = "checkBoxOption1")
	private WebElement checkBoxOpt1;
	
	@FindBy(id = "checkBoxOption2")
	private WebElement checkBoxOpt2;
	
	@FindBy(id = "checkBoxOption3")
	private WebElement checkBoxOpt3;
	
	// Mouse Hover Example
	@FindBy(id="mousehover")
	private WebElement mouseHovering;
	
	public ZPracticePage() {
		super();
		PageFactory.initElements(getDriver(), this);
	}
	
	public void selectRadioButton1() {
		action.click(getDriver(), radioButton1);
	}
	
	public void selectRadioButton2() {
		action.click(getDriver(), radioButton2);
	}
	
	public void suggestionClassExample() {
		action.click(getDriver(), autoCompleteTextBox);
	}

	public void dropDownExample() {
		action.selectByVisibleText("Option2", dropDownList1);
	}
	
	public void checkBoxExample() {
		action.click(getDriver(), checkBoxOpt1);
	}
	
	public void mouseHoverExample() {
		action.click(getDriver(), mouseHovering);
	}
}

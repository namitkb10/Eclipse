/**
 * 
 */
package com.webautomation.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
// import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

// import com.webautomation.pageobjects.IndexPage;
import com.webautomation.pageobjects.ZPracticePage;
//import com.portalsearch.dataprovider.DataProviders;
//import com.portalsearch.pageobjects.IndexPage;
//import com.portalsearch.utility.Log;
//import com.portalsearch.pageobjects.IndexPage;
import com.webautomation.base.BaseClass;

/**
 * @author namitkumar.burnwal
 *
 */
public class ZPracticePageTest extends BaseClass {
	
	//private IndexPage index;
	private ZPracticePage zPracticePage;
	
	// @Parameters("browser")
	// @BeforeMethod(groups = {"Smoke","Sanity","Regression"})
	@BeforeMethod
	public void setup() {
		System.out.println("Before Method");
		launchApp(prop.getProperty("browser"));
	}
	
	// @AfterMethod(groups = {"Smoke","Sanity","Regression"})
	@AfterMethod
	public void tearDown() {
		System.out.println("After Method");
		getDriver().quit();
	}
	
	@Test
	public void sampletest_1() throws InterruptedException {
		Thread.sleep(3000);
		zPracticePage.selectRadioButton1();
		Assert.assertTrue(true);
	}
	
	/*
	 * @Test public void sampletest_2() throws InterruptedException {
	 * Thread.sleep(3000); zPracticePage.dropDownExample(); Assert.assertTrue(true);
	 * 
	 * }
	 */
	
	@Test
	public void sampletest_3() throws InterruptedException {
		Thread.sleep(3000);
		zPracticePage.checkBoxExample();
		Assert.assertTrue(true);
		
	}
	
	/*
	 * @Test public void sampletest_4() throws InterruptedException {
	 * Thread.sleep(3000); zPracticePage.mouseHoverExample();
	 * Assert.assertTrue(true);
	 * 
	 * }
	 */

}

/**
 * 
 */
package com.paps.testcases;

import java.awt.AWTException;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.paps.base.BaseClass;
import com.paps.pageobject.PopupLogin_Page;

/**
 * @author namitkumar.burnwal
 *
 */
public class PopupLogin_Test extends BaseClass {
	
	PopupLogin_Page plp = new PopupLogin_Page(driver);
		
	@Test(priority = 1)
	public void WebLoginTest() throws InterruptedException, IOException, AWTException
	{
		plp.WebLoginPage();
			
		Thread.sleep(15000);

		String actualTitle = driver.getTitle();
		String expectedTitle = "Flexera Software App Portal";
		
		System.out.println("The page title is: " + actualTitle);
		
		Assert.assertEquals(actualTitle, expectedTitle);
	}
}

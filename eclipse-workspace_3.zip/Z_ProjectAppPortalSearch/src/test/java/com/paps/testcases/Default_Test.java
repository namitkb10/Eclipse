/**
 * 
 */
package com.paps.testcases;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.paps.base.BaseClass;
import com.paps.pageobject.Default_Page;

/**
 * @author namitkumar.burnwal
 *
 */
public class Default_Test extends BaseClass {
	
	Default_Page dp = new Default_Page(driver);
	
	@Test(priority = 2)
	public void editCatalogBehaviorTest() throws InterruptedException
	{
		
		dp.editCatalogBehavior();
		
		String savedMessage = driver.findElement(By.xpath("//span[text()='Settings Saved.']")).getText();
		
		String expectedMessage = "Settings Saved.";
		
		Assert.assertEquals(savedMessage, expectedMessage);
		
	}
}

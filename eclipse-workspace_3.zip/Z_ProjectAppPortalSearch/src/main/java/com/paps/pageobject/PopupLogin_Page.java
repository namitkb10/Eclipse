/**
 * 
 */
package com.paps.pageobject;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.paps.base.BaseClass;

/**
 * @author namitkumar.burnwal
 *
 */
public class PopupLogin_Page  extends BaseClass  {
	
	// WebDriver driver;

	
	public PopupLogin_Page(WebDriver rdriver) {
		
		// BaseClass.driver = rdriver;
		this.driver = rdriver;
		PageFactory.initElements(driver, this);
	}
	
	public void WebLoginPage()  throws InterruptedException, IOException, AWTException 
	{
		System.out.println("Verify the Login");
		System.out.println("PopupLogin_Page Chrome Driver: " + driver);
	}
}

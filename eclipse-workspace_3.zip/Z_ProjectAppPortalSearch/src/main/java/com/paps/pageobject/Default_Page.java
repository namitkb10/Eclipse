/**
 * 
 */
package com.paps.pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.paps.actiondriver.ActionMethod;
import com.paps.base.BaseClass;

/**
 * @author namitkumar.burnwal
 *
 */
public class Default_Page  extends BaseClass{

	// WebDriver driver;
	ActionMethod act;

	public Default_Page(WebDriver rdriver) {

		this.driver = rdriver;
		// BaseClass.driver = rdriver;
		PageFactory.initElements(driver, this);
		// PageFactory.initElements(driver, askLocator.class:);
	}
	
	//@FindBy(id="Admin") WebElement adminTab;
	@FindBy(id="tnSiteConfiguration")
	private WebElement siteManagementTab;
	
	@FindBy(id="nodeSettings")
	private WebElement nodeSettingTab;
	
	@FindBy(id="RadPanelItem121")
	private WebElement websiteTab;
	
	@FindBy(xpath = "//span[contains(text(),'Catalog Behavior')]")
	// @FindBy(how = How.XPATH, using = "//span[contains(text(),'Catalog Behavior')]")
	private WebElement catalogBehaviorBtn;

	public void editCatalogBehavior() throws InterruptedException
	{
		WebElement admin1 = driver.findElement(By.id("Admin"));
		
		System.out.println("Chrome ID is: " + driver);
		System.out.println("Admin is: " + admin1);
		
		act.click(driver, admin1);
		
		//adminTab.click();
		//Thread.sleep(5000);
		
		driver.findElement(By.id("tnSiteConfiguration")).click();
		// siteManagementTab.click();
		Thread.sleep(5000);
		
		driver.findElement(By.id("nodeSettings")).click();
		// nodeSettingTab.click();
		Thread.sleep(5000);
		
		driver.findElement(By.id("RadPanelItem121")).click();
		// websiteTab.click();
		Thread.sleep(5000);
		
		driver.switchTo().frame("RAD_SPLITTER_PANE_EXT_CONTENT_ctl00_cph1_topPane");
		Thread.sleep(5000);
		
		System.out.println("Switched to Frame");
		
		//driver.findElement(By.xpath("//span[contains(text(),'Catalog Behavior')]")).click();
		System.out.println("Default Page Chrome Driver: " + driver);
		catalogBehaviorBtn.click();
		
		
		
		System.out.println("Clicked on Catalog Behavior Button");
		
		WebElement weChkBoxSearchKeyword = driver.findElement(By.id("ctl00_cph1_keywordSearch"));
		WebElement weChkBoxSearchDescription = driver.findElement(By.id("ctl00_cph1_descriptionSearch"));
		
		for (int i = 0; i < 10; i++) {
			weChkBoxSearchKeyword.click();
			Thread.sleep(1000);
			weChkBoxSearchDescription.click();
			Thread.sleep(1000);
			weChkBoxSearchDescription.click();
			Thread.sleep(1000);
		}
		
		driver.findElement(By.xpath("//a[@class='rtbWrap']")).click();
		
		Thread.sleep(5000);
	}
}

package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ReadPropertiesFile {
	
	public String readConfig(String keyValue) throws IOException
	{
		File fileName = new File("C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Usecase\\Configuration\\Config.properties");
		FileInputStream fis = new FileInputStream(fileName);
		Properties prop = new Properties();
		prop.load(fis);
		return prop.getProperty(keyValue);
	}
}
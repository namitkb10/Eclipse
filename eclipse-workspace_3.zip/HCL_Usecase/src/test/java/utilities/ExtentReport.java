package utilities;

import java.io.File;

import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReport {
	
	public static ExtentReport getExtentReport()
	{
		ExtentReport extentReport = new ExtentReport();
		File extentReportFile = new File(System.getProperty("user.dir") + "\\ExtentReport\\Report.html");
		ExtentSparkReporter extentSparkReporter = new ExtentSparkReporter(extentReportFile);
		// extentReport.
		//48:36
		return extentReport;
		
	}

}

package usecase_Testcases;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Practice_Test_1 {
	
	public static WebDriver driver;
	static String url = "https://demowebshop.tricentis.com/";
	
	@Test
	public void ShoppingKart() throws InterruptedException
	{
		System.setProperty("WebDriver.chrome.driver", "C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Learning\\Driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		
		Assert.assertEquals(driver.getCurrentUrl(), url);
		
		// WebElement computerText = driver.findElement(By.xpath("//ul[@class='top-menu']/li/a[contains(text(), 'Computers')]"));
		WebElement computerText = driver.findElement(By.xpath("(//a[@href='/computers'])[1]"));
		
		
		Actions act = new Actions(driver);
		act.moveToElement(computerText).build().perform();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("(//a[@href='/desktops'])[1]")).click();
		Thread.sleep(2000);
		
		Assert.assertEquals(driver.getCurrentUrl(), "https://demowebshop.tricentis.com/desktops");
		
		WebElement dropDownPosition = driver.findElement(By.id("products-orderby"));
		
		Select sel = new Select(dropDownPosition);
		
		List<WebElement> lstWebElement = sel.getOptions();
		
		System.out.println("No of Element in position drop down: " + lstWebElement.size());
		
		for(int i=0; i<lstWebElement.size(); i++)
		{
			System.out.println(lstWebElement.get(i).getText());
		}
		
		//to perform Scroll on application using Selenium
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,300)", "");
		Thread.sleep(2000);
		// driver.findElement(By.xpath("//h2[@class='product-title']/a[text()='Build your own expensive computer']")).click();
		driver.findElement(By.linkText("Build your own expensive computer")).click();
		
		jse.executeScript("window.scrollBy(0,400)", "");
		Thread.sleep(2000);
		
		driver.findElement(By.id("product_attribute_74_5_26_82")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("product_attribute_74_6_27_85")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("product_attribute_74_3_28_87")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("product_attribute_74_8_29_89")).click();
		Thread.sleep(1000);
		
		//driver.findElement(By.xpath("//ul[@class='option-list']/li/input[@type='checkbox' and @value='89']")).click();
		
		WebElement weQty = driver.findElement(By.xpath("//input[@class='qty-input']"));
		Thread.sleep(2000);
		
		act.doubleClick(weQty).build().perform();
		Thread.sleep(2000);
		weQty.sendKeys("2");
		Thread.sleep(2000);
		driver.findElement(By.id("add-to-cart-button-74")).click();
		Thread.sleep(2000);
		jse.executeScript("window.scrollBy(0,-400)", "");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(text(),'Shopping cart')]")).click();
	}
}

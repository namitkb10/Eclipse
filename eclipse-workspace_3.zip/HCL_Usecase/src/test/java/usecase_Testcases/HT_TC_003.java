package usecase_Testcases;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import usecase_Pages.AboutUsPage;
import usecase_Pages.ContactUsPage;
import usecase_Pages.CorporateSocialPage;

public class HT_TC_003 extends Baseclass {
	
	AboutUsPage aboutuspage;
	ContactUsPage contactuspage;
	CorporateSocialPage csrPage;

	@Test(priority=1)
	public void capturingText() throws Exception
	{
		driver.navigate().to("https://www.hcltech.com/about-us");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		contactuspage.clickAcceptCookiesButton();
		
		contactuspage=PageFactory.initElements(driver, ContactUsPage.class);
		aboutuspage=PageFactory.initElements(driver, AboutUsPage.class);
		csrPage=PageFactory.initElements(driver, CorporateSocialPage.class);

		//contactuspage.cookiesAccept();
		aboutuspage.moveToAboutUs();
		csrPage.socialResponsibility();

		JavascriptExecutor js = (JavascriptExecutor) driver;
	    js.executeScript("window.scrollBy(0,750)", "");

		String TestFile="C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Usecase\\Actual_Textfile\\Actual_CorporateSocialResponsibility.txt";
		File FC= new File(TestFile);
		FC.createNewFile();
		
		FileWriter FW = new FileWriter(TestFile);
	    BufferedWriter BW = new BufferedWriter(FW);
	    
        BW.write(csrPage.information());
	    BW.newLine();
	    BW.close();

	    Assert.assertNotNull(BW);
	}

	@Test(priority=2)
	public void comparingTextFiles() {

		String ExpectedFile="C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Usecase\\Expected_Textfile\\Expected_CorporateSocialResponsibility.txt";
		driver.navigate().to(ExpectedFile);
		String expected=driver.getPageSource();
		String ActualFile="C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Usecase\\Actual_Textfile\\Actual_CorporateSocialResponsibility.txt";
		driver.navigate().to(ActualFile);
		String actual=driver.getPageSource();
		if(expected.equals(actual)) {
			System.out.println("actual and expected contents are equal");
		}
		else
		{
			System.out.println("actual and expected contents are not equal");			}
		}
}

package usecase_Testcases;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import ru.yandex.qatools.ashot.comparison.ImageDiff;
import ru.yandex.qatools.ashot.comparison.ImageDiffer;

import java.util.List;
import java.util.Set;

import javax.imageio.ImageIO;

public class Amazon_Case extends Baseclass {
	
	// JavascriptExecutor jse = (JavascriptExecutor)driver;
	// Actions act = new Actions(driver);
	
	@Test(priority = 1)
	public void menuSubmenuItems() throws InterruptedException, IOException
	{
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Thread.sleep(4000);
		driver.findElement(By.xpath("//a[text()='Mobiles']")).click();
		
		List<WebElement> menuItems = driver.findElements(By.xpath("//span[@class='nav-a-content']"));
		
		System.out.println("No of Menu Items: " + menuItems.size());
		
		for (WebElement element : menuItems) {
		    System.out.println(element.getText());
		}
		
		// Capture the screenshot and compare the screenshot with the expected screenshot
		
		//======================================================
		  BufferedImage expectedImage = ImageIO.read(new File("C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Usecase\\Expected_Screenshot\\Amazon_Mobiles_Click.png"));
		  
		  //capture screen shot
		  TakesScreenshot tss = (TakesScreenshot)driver;
		  File srcFile = tss.getScreenshotAs(OutputType.FILE);
		  File dstFile = new File("C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Usecase\\Actual_Screenshot\\Amazon_Mobiles_Click_Actual.png");
		  FileUtils.copyFile(srcFile, dstFile);
		  
		  BufferedImage actualImage = ImageIO.read(dstFile);
		  
		  // Compare the Images
		  ImageDiffer imageDiffer = new ImageDiffer();
		  ImageDiff imageDiff = imageDiffer.makeDiff(expectedImage, actualImage);
		  
		  System.out.println();
		  System.out.println();
		  
		  if (imageDiff.hasDiff() == true) {
			  System.out.println("Screen Shots are not same");
			  System.out.println("Images Not Matching");
			  // Assert.fail("Images Not Matching");
		  }
		  else
		  {
			  System.out.println("Screen Shots are same");
			  System.out.println("Images Matched");
			  Assert.assertEquals(expectedImage, actualImage);
		  }
		
		//======================================================
		Actions act = new Actions(driver);
		act.moveToElement(driver.findElement(By.xpath("//span[@class='nav-a-content' and contains(text(),'Laptops & Accessories')]"))).build().perform();
		
		WebElement laptopBrand = driver.findElement(By.xpath("//a[text()='Dell']"));
		
		act.moveToElement(laptopBrand).build().perform();
		Thread.sleep(2000);
		laptopBrand.click();
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,500)", "");
		
		driver.findElement(By.id("low-price")).sendKeys("40000");
		driver.findElement(By.id("high-price")).sendKeys("100000");
		driver.findElement(By.xpath("//span[@class='a-button-inner']/input")).click();
		
		jse.executeScript("window.scrollBy(0,-500)", "");
		
		// driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("Gaming Laptop");
		// driver.findElement(By.xpath("//input[@id='nav-search-submit-button']")).click();
		String currentHandle= driver.getWindowHandle();
		System.out.println("Current Window: " + currentHandle);
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Gaming Laptop", Keys.ENTER);
		
		jse.executeScript("window.scrollBy(0,300)", "");
		
		String displayResult = driver.findElement(By.xpath("//span[@class='a-size-medium-plus a-color-base a-text-bold' and text()='Results']")).getText();
		Assert.assertEquals(displayResult, "Results");
		
		driver.findElement(By.xpath("(//span[@class='a-size-medium a-color-base a-text-normal'])[1]")).click();
		Thread.sleep(3000);
		Set<String> handles=driver.getWindowHandles();
		for(String actual: handles)
		{
			System.out.println(actual);
			if(!actual.equalsIgnoreCase(currentHandle)) {
				//Switch to the opened tab
				driver.switchTo().window(actual);
			}
		}
		
		jse.executeScript("window.scrollBy(0,100)", "");
		System.out.println("Current Title: "+ driver.getTitle());
		Thread.sleep(6000);
		String strPrice = driver.findElement(By.xpath("//span[@class='a-price aok-align-center reinventPricePriceToPayMargin priceToPay']//span[@class='a-price-whole']")).getText();
		System.out.println(strPrice);
		strPrice.replace(",", "");
		System.out.println(strPrice);
		
		// Integer intPrice = Integer.valueOf(strPrice); 
		// int intPrice = Integer.parseInt(strPrice);
		// Assert.assertTrue(intPrice > 0);
		
		act.moveToElement(driver.findElement(By.xpath("//div[@id='contextualIngressPtLabel_deliveryShortLine']"))).build().perform();

		driver.findElement(By.xpath("//div[@id='contextualIngressPtLabel_deliveryShortLine']")).click();
		  
		driver.findElement(By.xpath("//input[@class='GLUX_Full_Width a-declarative']")).sendKeys("826001");
		driver.findElement(By.xpath("//div[@id='GLUXZipInputSection']//input[@type='submit']")).click();
		
		for (int i = 0; i < 275; i++) {
			jse.executeScript("window.scrollBy(0,40)", "");
			Thread.sleep(1);
		}
		
		Thread.sleep(3000);
		act.moveToElement(driver.findElement(By.xpath("//h2[text()='Customer reviews']")));
		String ratingNote = driver.findElement(By.xpath("//span[@class='a-size-medium a-color-base' and contains(text(),'out of 5')]")).getText();
		System.out.println("Ratings: " + ratingNote);
		
		act.moveToElement(driver.findElement(By.xpath("//h3[contains(text(),'Top reviews from India')]")));
		
		List<WebElement> customerTopReviewTitle = driver.findElements(By.xpath("//a[@class='a-size-base a-link-normal review-title a-color-base review-title-content a-text-bold']/span[2]"));
		
		System.out.println("Top review counts: " + customerTopReviewTitle.size());
		
		// 13. Read the customer review under "Top reviews from India". Embed the content into an excel sheet.
		//====================================================================
        /* File file = new File("C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Usecase\\Utilities\\Amazon_Customer_Reviews.xlsx");
		
		FileInputStream fis = new FileInputStream(file);
		
		Workbook wb = WorkbookFactory.create(fis);
		
		Sheet sh = wb.getSheet("Sheet1");
		
		// int rowIndex = sh.getLastRowNum();
		
		//System.out.println("Total Number Of Row: " + rowIndex);
		System.out.println();

		FileOutputStream fos = new FileOutputStream(file);
		
		for (int i = 1; i <= rowIndex; i++) {
			Row row = sh.getRow(i);
			
			// String userName = row.getCell(0).getStringCellValue();
			// String pass = row.getCell(1).getStringCellValue();
			
			row.getCell(2).setCellValue("Pass");

			wb.write(fos);
			
			// String status = row.getCell(2).getStringCellValue();
			
			// System.out.println(userName + "  &&  " + pass + " && " + status);
		}
		// fis.close();
		fos.close();
//		sh.getRow(0).createCell(2).setCellValue("Pass");
//		sh.getRow(0).createCell(2).setCellValue("Pass");
//		FileOutputStream fos = new FileOutputStream(file);
		wb.close(); */
		
		//====================================================================
		for (WebElement reviewTitle : customerTopReviewTitle) {
		    System.out.println(reviewTitle.getText());
		}
		
		// Here, write it to excel sheet
		
		jse.executeScript("window.scrollBy(0,-15000)", "");
		jse.executeScript("window.scrollBy(0,500)", "");
		
		driver.findElement(By.xpath("//input[@id='add-to-cart-button']")).click();
		Thread.sleep(5000);
		
		String verifyAddedTocart = driver.findElement(By.xpath("//div[@id='attachDisplayAddBaseAlert']//h4[text()='Added to Cart']")).getText(); 
		
		Assert.assertEquals(verifyAddedTocart,"Added to Cart");
		
		//Assert.assertEquals(driver.getTitle(), "HCLTech: Supercharging Progress | Digital, Engineering and Cloud");
	}
}

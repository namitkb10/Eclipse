package usecase_Testcases;

import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import ru.yandex.qatools.ashot.comparison.ImageDiff;
import ru.yandex.qatools.ashot.comparison.ImageDiffer;
import usecase_Pages.ContactUsPage;

public class HT_TC_004 extends Baseclass {

	ContactUsPage contactuspage;

	@Test(priority = 1)
	public void compareScreenshots() throws Throwable {

		driver.get("https://www.hcltech.com/about-us");

		driver.manage().window().maximize();

		Thread.sleep(3000);
		
		contactuspage.clickAcceptCookiesButton();

		contactuspage = PageFactory.initElements(driver, ContactUsPage.class);

		String actualtitle = driver.getTitle();

		Assert.assertEquals(actualtitle, "About our Company: HCLTech – Supercharging Progress");

		System.out.println("title is " + actualtitle);

		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("window.scrollBy(0,3000)", "");

		BufferedImage expectedImage = ImageIO.read(	new File("C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Usecase\\Expected_Screenshot\\AboutUs.png"));

		//capture screen shot
		TakesScreenshot tss = (TakesScreenshot)driver;
		File srcFile = tss.getScreenshotAs(OutputType.FILE);
		File dstFile = new File("C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Usecase\\Actual_Screenshot\\AboutUs.png");
		FileUtils.copyFile(srcFile, dstFile);

		BufferedImage actualImage = ImageIO.read(dstFile);

		// compare the screenshots
		ImageDiffer imagediff = new ImageDiffer();

		ImageDiff diff = imagediff.makeDiff(expectedImage, actualImage);

		if (diff.hasDiff() == true) {

			System.out.println("Screenshots are not same");

			Assert.fail("Screenshots not matching");

		} else {

			System.out.println("Screenshots are same & matched");
			Assert.assertEquals(expectedImage, actualImage);
		}
	}
}

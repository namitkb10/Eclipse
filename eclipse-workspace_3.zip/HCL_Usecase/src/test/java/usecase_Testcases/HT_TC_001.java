package usecase_Testcases;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.Duration;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import ru.yandex.qatools.ashot.comparison.ImageDiff;
import ru.yandex.qatools.ashot.comparison.ImageDiffer;
import usecase_Pages.ContactUsPage;
import usecase_Pages.HomePage;

public class HT_TC_001 extends Baseclass {
	
	ContactUsPage cp;
	HomePage hp;
	
	@Test(priority = 1)
	public void menuSubmenuItems() throws InterruptedException
	{
		driver.get("https://www.hcltech.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		cp=PageFactory.initElements(driver, ContactUsPage.class);
		Thread.sleep(2000);
		
		cp.clickAcceptCookiesButton();
		hp = PageFactory.initElements(driver, HomePage.class);
		
		hp.displayMenuSubmenuList();
		Assert.assertEquals(driver.getTitle(), "HCLTech: Supercharging Progress | Digital, Engineering and Cloud");
	}
	
	
	  @Test(priority = 2)
	  public void captureAndCompareScreenShot() throws IOException
	  {
		  BufferedImage expectedImage = ImageIO.read(new File("C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Usecase\\Expected_Screenshot\\HCLtech_Launches.png"));
	  
		  //capture screen shot
		  TakesScreenshot tss = (TakesScreenshot)driver;
		  File srcFile = tss.getScreenshotAs(OutputType.FILE);
		  File dstFile = new File("C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Usecase\\Actual_Screenshot\\HCLtech_Launches_Actual.png");
		  FileUtils.copyFile(srcFile, dstFile);
		  
		  BufferedImage actualImage = ImageIO.read(dstFile);
		  
		  // Compare the Images
		  ImageDiffer imageDiffer = new ImageDiffer();
		  ImageDiff imageDiff = imageDiffer.makeDiff(expectedImage, actualImage);

		  if (imageDiff.hasDiff() == true) {
			  System.out.println("Screen Shots are not same");
			  Assert.fail("Images Not Matching");
		  }
		  else
		  {
			  System.out.println("Screen Shots are same");
			  Assert.assertEquals(expectedImage, actualImage);
		  }
	  }
}

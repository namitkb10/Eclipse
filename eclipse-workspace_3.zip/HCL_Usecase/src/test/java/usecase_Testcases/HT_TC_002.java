package usecase_Testcases;

import java.awt.AWTException;
import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import usecase_Pages.ContactUsPage;
import usecase_Pages.HomePage;
import utilities.ReadPropertiesFile;

public class HT_TC_002 extends Baseclass {
	
	ContactUsPage cp;
	ReadPropertiesFile rpf;
	
	@Test
	public void navigateToContactUsPage() throws InterruptedException
	{
		driver.get("https://www.hcltech.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		cp.clickAcceptCookiesButton();
		
		cp=PageFactory.initElements(driver, ContactUsPage.class);
		Thread.sleep(2000);
		
		// ContactUsPage
		cp.clickOnContactUsPage();
	}
	
	@Test
	public void setUpTheData() throws InterruptedException, IOException, AWTException
	{
		cp.fillContactUsData();
	}
}

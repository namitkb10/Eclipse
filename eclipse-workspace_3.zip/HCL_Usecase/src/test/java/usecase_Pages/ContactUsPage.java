package usecase_Pages;

import static org.testng.Assert.assertSame;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import utilities.ReadPropertiesFile;

public class ContactUsPage {
	
	WebDriver driver;
	
	@FindBy(how=How.ID, using="onetrust-accept-btn-handler")
	WebElement acceptCookies;
	
	@FindBy(how=How.XPATH, using="//a[@title='Contact Us']")
	WebElement contactUs;
	
	@FindBy(how=How.NAME, using="full_name")
	WebElement fullName;
	
	@FindBy(how=How.NAME, using="email_address")
	WebElement businessEmail;
	
	@FindBy(how=How.NAME, using="organization")
	WebElement organization;
	
	@FindBy(how=How.NAME, using="phone")
	WebElement phone;
	
	@FindBy(how=How.NAME, using="country")
	WebElement dropDownCountry;
	
	@FindBy(how=How.NAME, using="query_type")
	WebElement dropDownRelationship;
	
	@FindBy(how=How.NAME, using="message_comments")
	WebElement multiBoxHelp;
	
	@FindBy(how=How.ID, using="edit-upload-multifile--label")
	WebElement fileUpload;
	
	@FindBy(how=How.NAME, using="privacy_policy")
	WebElement termsAndConditions;
	
	//input[@id='edit-full-name']
	
	public ContactUsPage(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void clickOnContactUsPage()
	{
		contactUs.click();
		assertSame(driver.getTitle(), "Contact Us | HCLTech");
		// acceptCookies.click();
	}
	
	public void clickAcceptCookiesButton()
	{
		acceptCookies.click();
	}
	
	public void fillContactUsData() throws IOException, AWTException
	{
		ReadPropertiesFile rpf = new  ReadPropertiesFile();
		fullName.sendKeys(rpf.readConfig("fullname"));
		businessEmail.sendKeys(rpf.readConfig("businessemail"));
		organization.sendKeys(rpf.readConfig("organization"));
		phone.sendKeys(rpf.readConfig("phone"));
		
		// scroll to reach upload button
	    JavascriptExecutor j = (JavascriptExecutor)driver;
	    j.executeScript("scroll(0,1000)");
		
		Select sel = new Select(dropDownCountry);
		sel.selectByValue("IN");
		
		/*
		 * // file path passed as parameter to StringSelection // StringSelection s =
		 * new StringSelection(
		 * "C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Usecase\\File_Upload\\Upload_File.txt"
		 * ); StringSelection s = new
		 * StringSelection("C:\\Users\\namitkumar.burnwal\\Upload_Text.txt"); //
		 * Clipboard copy
		 * Toolkit.getDefaultToolkit().getSystemClipboard().setContents(s,null);
		 * //identify element and click //
		 * driver.findElement(By.xpath("//*[text()='Choose file']")).click();
		 * fileUpload.click(); // Robot object creation Robot r = new Robot();
		 * //pressing enter r.keyPress(KeyEvent.VK_ENTER); //releasing enter
		 * r.keyRelease(KeyEvent.VK_ENTER); //pressing ctrl+v
		 * r.keyPress(KeyEvent.VK_CONTROL); r.keyPress(KeyEvent.VK_V); //releasing
		 * ctrl+v r.keyRelease(KeyEvent.VK_CONTROL); r.keyRelease(KeyEvent.VK_V);
		 * //pressing enter r.keyPress(KeyEvent.VK_ENTER); //releasing enter
		 * r.keyRelease(KeyEvent.VK_ENTER);
		 */
		
		/* Select sel = new Select(dropDownRelationship);
		sel.deselectByValue("IN");*/
		
		multiBoxHelp.sendKeys(rpf.readConfig("message"));
		fileUpload.sendKeys("C:\\Users\\namitkumar.burnwal\\eclipse-workspace\\HCL_Usecase\\File_Upload\\Upload_File.txt");
		termsAndConditions.click();
	}
}

package usecase_Pages;


import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
	WebDriver driver;
	
	@FindBy(how=How.TAG_NAME, using= "a")
	List<WebElement> menuSubmenuList;
	
	public HomePage(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void displayMenuSubmenuList()
	{
		System.out.println("Menu & Submenu Size: " + menuSubmenuList.size());
		System.out.println("Display Menu & Submenu");
		for (WebElement menuSubmenu : menuSubmenuList) {
			System.out.println(menuSubmenu.getText());
		}
	}
}

package usecase_Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CorporateSocialPage {

	WebDriver driver;

	@FindBy(xpath = "//a[@class='nav-link--corporate-social-responsibility'][@title='Corporate Social Responsibility']")
	WebElement corporate;

	@FindBy(xpath = "//div[@class='additional-information-info']")
	WebElement infomation;

	public CorporateSocialPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void socialResponsibility() {
		corporate.click();
	}

	public String information() {
		String element = infomation.getText();
		return element;
	}
}
package usecase_Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class AboutUsPage {
	
	WebDriver driver;
	@FindBy(how=How.XPATH, using="//a[@title='About Us']")
	
	WebElement aboutUs;
	
	public AboutUsPage(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void moveToAboutUs()
	{
		Actions act = new Actions(driver);
		act.moveToElement(aboutUs).build().perform();
	}
}

/**
 * 
 */
package com.sd.testcases;

import org.testng.Assert;
//import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.sd.base.BaseClass;
import com.sd.pageobject.SignInIndexPage;
import com.sd.pageobject.RegistrationLoginPage;

/**
 * @author namitkumar.burnwal
 *
 */
public class SignInIndexPageTest extends BaseClass {
	
	// WebDriver driver;
	// SignInIndexPage siip = new SignInIndexPage(driver);
	
	@Test(priority = 1)
	public void clickOnSignIn() {
		
		// DateTime dt = new DateTime();
		SignInIndexPage siip = new SignInIndexPage(driver);
		 
		System.out.println("SignInIndexPageTest Driver-1: " + driver);
		siip.clickSignInButton();
		
		RegistrationLoginPage rlp = new RegistrationLoginPage(driver);
		
		String actualTitle = rlp.verifyTitle();
		String expectedTitle = "Login - My Store";
		Assert.assertEquals(actualTitle, expectedTitle);
	}
}

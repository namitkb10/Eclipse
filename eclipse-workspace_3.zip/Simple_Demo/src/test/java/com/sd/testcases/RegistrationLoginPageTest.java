/**
 * 
 */
package com.sd.testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.sd.base.BaseClass;
import com.sd.pageobject.RegistrationLoginPage;
// import com.sd.pageobject.SignInIndexPage;

/**
 * @author namitkumar.burnwal
 *
 */
// public class RegistrationLoginPageTest extends BaseClass {
public class RegistrationLoginPageTest extends BaseClass {
	
	// SignInIndexPage siip;
	//WebDriver driver;
	RegistrationLoginPage rlpt;
	
	@Test(priority = 2)
	public void alreadyRegisterdTest() {
		
		// siip = new SignInIndexPage(driver);
		 
		// System.out.println("SignInIndexPageTest Driver: " + driver);
		// siip.clickSignInButton();
		//==============================================================================
		rlpt = new RegistrationLoginPage(driver);
		
		System.out.println("RegistrationLoginPageTest Driver-3: " + driver);
		rlpt.alreadyRegisterd();
				
		String actualTitle = rlpt.verifyTitle();
		String expectedTitle = "Login - My Store";
		Assert.assertEquals(actualTitle, expectedTitle);
		
	}
	
	@Test(priority = 3)
	public void notregisteredEmailID() {
		// Verify Email not registered
		driver.findElement(By.id("email_create")).sendKeys("namitkb22@gmail.com");
		driver.findElement(By.id("SubmitCreate")).click();
	}
	
	

}

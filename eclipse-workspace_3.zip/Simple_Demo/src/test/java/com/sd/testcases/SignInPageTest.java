/**
 * 
 */
package com.sd.testcases;

import java.util.ResourceBundle;

// import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
// import org.openqa.selenium.chrome.ChromeDriver;
// import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.sd.base.BaseClass;

import org.openqa.selenium.JavascriptExecutor;

// import io.github.bonigarcia.wdm.WebDriverManager;


/**
 * @author namitkumar.burnwal
 *
 */
public class SignInPageTest extends BaseClass {
	// public static WebDriver driver;
	
	public String strEmail = "namitkb22@gmail.com";
	Select sel;
	Actions actions;

	@Test
	public void signInTest() throws InterruptedException
	{
		
		ResourceBundle rb = ResourceBundle.getBundle("config");
		String url = rb.getString("baseUrl");
		String browse = rb.getString("browser");
		System.out.println(url);
		System.out.println(browse);
		/* WebDriverManager.chromedriver().setup();

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(options);
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(30, TimeUnit.SECONDS);
		driver.get("http://automationpractice.pl/index.php");
		Thread.sleep(5000);*/
		// Index Page - http://automationpractice.pl/index.php
		
		// Cursor move to element 
		 actions = new Actions(driver);
		 WebElement loginButton = driver.findElement(By.xpath("//a[@class='login']"));
		 actions.moveToElement(loginButton);
		
		 loginButton.click();
		
		// Login/Registration Page - http://automationpractice.pl/index.php?controller=authentication&back=my-account
		Thread.sleep(5000);
		
		// to perform Scroll on application using Selenium
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,350)", "");
		
		// Login using valid credentials
		driver.findElement(By.id("email")).sendKeys(strEmail);
		driver.findElement(By.id("passwd")).sendKeys("Artelus@22");
		driver.findElement(By.id("SubmitLogin")).click();
		
		// Authentication Error Verify
		String strMessageActual = driver.findElement(By.xpath("//ol/li[text()='Authentication failed.']")).getText();
		if(!strMessageActual.isEmpty())
		{
			Assert.assertEquals(strMessageActual, "Authentication failed.");
			System.out.println("Not Null");
		}
		
		// Verify Email not registered
		driver.findElement(By.id("email_create")).sendKeys(strEmail);
		driver.findElement(By.id("SubmitCreate")).click();
		
		//Register yourself
		driver.findElement(By.id("id_gender1")).click();
		driver.findElement(By.id("customer_firstname")).sendKeys("Namit");
		driver.findElement(By.id("customer_lastname")).sendKeys("KB");
		// This field will come from previous 
		//driver.findElement(By.id("email")).sendKeys(strEmail);
		driver.findElement(By.id("passwd")).sendKeys("Artelus@22");
		
		// Slect from Drop Down List
		// Select Days
		WebElement selectDay = driver.findElement(By.id("days"));
		sel = new Select(selectDay);
		sel.selectByValue("2");
		
		// Select Month
		WebElement selectMonth = driver.findElement(By.id("months"));
		sel = new Select(selectMonth);
		sel.selectByValue("1");
		
		// Select Year
		WebElement selectYear = driver.findElement(By.id("years"));
		sel = new Select(selectYear);
		sel.selectByValue("2000");
		
		driver.findElement(By.id("newsletter")).click();
		driver.findElement(By.id("optin")).click();
		
		// driver.findElement(By.id("submitAccount")).click();
		
	}
}

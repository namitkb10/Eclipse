/**
 * 
 */
package com.sd.testcases;

import org.testng.annotations.Test;

import com.sd.base.BaseClass;
import com.sd.pageobject.RegistrationPage;

/**
 * @author namitkumar.burnwal
 *
 */
public class RegistrationPageTest extends BaseClass {

	RegistrationPage rp;
	
	@Test()
	public void registerNowTest()
	{
		rp = new RegistrationPage(driver);
		rp.registerNow();
	}
}

/**
 * 
 */
package com.sd.base;

import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * @author namitkumar.burnwal
 *
 */
public class BaseClass {
	
	public static WebDriver driver;
	
	@BeforeTest
	public void setup() throws InterruptedException
	{
		WebDriverManager.chromedriver().setup();

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(options);
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(30, TimeUnit.SECONDS);
		driver.get("http://automationpractice.pl/index.php");
		Thread.sleep(5000);
		
		ResourceBundle rb = ResourceBundle.getBundle("config");
		String url = rb.getString("baseUrl");
		String browse = rb.getString("browser");
		System.out.println(url);
		System.out.println(browse);
	}
	
	@AfterTest
	public void tearDown()
	{
		//driver.close();
		//driver.quit();
	}
}

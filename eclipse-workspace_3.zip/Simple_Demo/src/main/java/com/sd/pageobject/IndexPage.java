/**
 * 
 */
package com.sd.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.sd.actiondriver.Action;
import com.sd.base.BaseClass;

/**
 * @author namitkumar.burnwal
 *
 */
public class IndexPage extends BaseClass {

	// 1. create object of webdriver
	WebDriver ldriver;
	Action action = new Action();

	// constructor
	public IndexPage(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy(xpath = "\\a[@class='login']")
	WebElement loginButton;

	public void clickSignInButton(WebDriver lDriver) {

		loginButton.click();

	}
}

/**
 * 
 */
package com.sd.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.sd.actiondriver.Action;
import com.sd.base.BaseClass;

/**
 * @author namitkumar.burnwal
 *
 */
public class SignInIndexPage extends BaseClass {
	
	@FindBy(xpath="//a[@class='login']")
	WebElement loginButton;
	//WebDriver driver;
	
	// Initialize page objects
	public SignInIndexPage(WebDriver rDriver)
	{
		this.driver = rDriver;
		PageFactory.initElements(driver, this);
	}
	
	
	public void clickSignInButton() {
		
		System.out.println("SignInIndexPage Driver-2: " + driver);
		loginButton.click();
	}
}

/**
 * 
 */
package com.sd.pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.sd.base.BaseClass;

/**
 * @author namitkumar.burnwal
 *
 */
public class RegistrationLoginPage extends BaseClass {
	//WebDriver driver;
	
	String strEmail="namitkb22@gmail.com";

	public RegistrationLoginPage(WebDriver rDriver) {

		this.driver = rDriver;
		PageFactory.initElements(driver, this);
	}

	public String verifyTitle() {
		System.out.println("RegistrationLoginPage Driver-4: " + driver);
		return driver.getTitle();
	}

	public void alreadyRegisterd() {

		// Login using valid credentials
		// driver.findElement(By.id("email")).sendKeys(strEmail);
		driver.findElement(By.id("email")).sendKeys(strEmail);
		driver.findElement(By.id("passwd")).sendKeys("Artelus@22");
		driver.findElement(By.id("SubmitLogin")).click();

		// Authentication Error Verify
		String strMessageActual = driver.findElement(By.xpath("//ol/li[text()='Authentication failed.']")).getText();
		if (!strMessageActual.isEmpty()) {
			Assert.assertEquals(strMessageActual, "Authentication failed.");
			System.out.println("Not Null Verified");
		}
	}

}

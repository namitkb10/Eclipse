/**
 * 
 */
package com.sd.pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.sd.base.BaseClass;

/**
 * @author namitkumar.burnwal
 *
 */
public class RegistrationPage extends BaseClass {
	
	String strEmail = "namitkb22@gmail.com";
	Select sel;
	
	public RegistrationPage(WebDriver rDriver) {

		BaseClass.driver = rDriver;
		PageFactory.initElements(BaseClass.driver, this);
	}
	
	
	public void registerNow()
	{
				
				//Register yourself
				driver.findElement(By.id("id_gender1")).click();
				driver.findElement(By.id("customer_firstname")).sendKeys("Namit");
				driver.findElement(By.id("customer_lastname")).sendKeys("KB");
				// This field will come from previous 
				//driver.findElement(By.id("email")).sendKeys(strEmail);
				driver.findElement(By.id("passwd")).sendKeys("Artelus@22");
				
				// Slect from Drop Down List
				// Select Days
				WebElement selectDay = driver.findElement(By.id("days"));
				sel = new Select(selectDay);
				sel.selectByValue("2");
				
				// Select Month
				WebElement selectMonth = driver.findElement(By.id("months"));
				sel = new Select(selectMonth);
				sel.selectByValue("1");
				
				// Select Year
				WebElement selectYear = driver.findElement(By.id("years"));
				sel = new Select(selectYear);
				sel.selectByValue("2000");
				
				driver.findElement(By.id("newsletter")).click();
				driver.findElement(By.id("optin")).click();
				
				// driver.findElement(By.id("submitAccount")).click();
	}

}

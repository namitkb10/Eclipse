package string_Program;

import java.util.ArrayList;

public class Repeated_Count_In_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Method-1");
		String str = "divyajyotibharti";
		//String dupStr="";
		int count = 1;
		String[] strArr = str.split("");
		
		ArrayList<String> strArrList = new ArrayList<String>();
		
		for (int i = 0; i < strArr.length; i++) {
			if(!strArrList.contains(strArr[i]))
			{
				count = 1;
				strArrList.add(strArr[i]);
				for (int j = i+1; j < strArr.length; j++) {
					if(strArr[i].equalsIgnoreCase(strArr[j]))
					{
						count++;
					}
				}
				System.out.println(strArr[i] + " repeats " + count + " times ");
			}
		}
		// ===========================================================================
		System.out.println("Method-2");
		System.out.println("=============================================================");
		String str1 = "namitkumarburnwal";
		for (int i = 0; i < str1.length(); i++) {
			if(!str1.contains(strArr[i]))
			{
				count = 1;
				strArrList.add(strArr[i]);
				for (int j = i+1; j < strArr.length; j++) {
					if(strArr[i].equalsIgnoreCase(strArr[j]))
					{
						count++;
					}
				}
				System.out.println(strArr[i] + " repeats " + count + " times ");
			}
		}
	}
}

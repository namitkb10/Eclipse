package string_Program;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Repeated_Count_In_String1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count=1;
		Scanner scn = new Scanner(System.in);
		System.out.print("Please Enter a String: ");
		String str = scn.next();
		
		System.out.println("Entered String is: " + str);
		
		String[] strArr = str.split("");
		
		List<String> strArrList = new ArrayList<String>();
		
		for (int i = 0; i < strArr.length; i++) {
			count=1;
			if(!strArrList.contains(strArr[i]))
			{
				strArrList.add(strArr[i]);
				for (int j = i+1; j < strArr.length; j++) {
					if(strArr[i].equalsIgnoreCase(strArr[j]))
					{
						count++;
					}
				}
				System.out.println(strArr[i] + " repeated " + count + " times");
			}
		}
	}
}
package arraysList;

import java.util.Arrays;

public class Array_2nd_Highest_Smallest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Method-1");
		int[] num1 = {10,40,20,8,50,5,25};
		int temp;
		for (int i = 0; i < num1.length; i++) {
			for (int j = i+1; j < num1.length; j++) {
				// if(num[i] < num[j]) // 2nd Highest
				if(num1[i] > num1[j]) // 2nd Smallest
				{
					temp=num1[i];
					num1[i]=num1[j];
					num1[j]=temp;
				}
			}
		}
		System.out.println("2nd smallest No: " + num1[1]);
		System.out.println("2nd highest No: " + num1[num1.length-2]);
		// System.out.println("2nd highest No: " + num[1]);
		
		System.out.println("==========================================================");
		System.out.println("Method-2");
		int[] num2 = {10,40,20,8,50,5,25};
		int size = num2.length;
		Arrays.sort(num2);
	    System.out.println("Sorted Array: " + Arrays.toString(num2));
	    int res = num2[size-2];
	    System.out.println("2nd largest element is: " + res);
	    
		System.out.println("==========================================================");
		System.out.println("Method-3");
		int[] numbers = {10,40,20,8,50,5,25};
    	
        int max=0;
        int secondHighest=0;
        for (int i = 0; i < numbers.length; i++)
        {       
            if (numbers[i]>max)
            {
                secondHighest=max;
                max=numbers[i];
            }
            if (numbers[i]<max && numbers[i]>=secondHighest )
            {
                secondHighest=numbers[i];
            }
        }
        System.out.println("Second highest number is: " + secondHighest);
        System.out.println("Max number is: " + max);
		
		System.out.println("==========================================================");
	}
}

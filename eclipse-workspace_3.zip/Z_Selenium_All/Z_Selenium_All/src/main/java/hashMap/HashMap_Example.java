package hashMap;

import java.util.HashMap;
import java.util.Map;

public class HashMap_Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer, String> hMap = new HashMap<Integer, String>();
		hMap.put(1, "Namit");
		hMap.put(2, "Kumar");
		hMap.put(3, "Burnwal");
		hMap.put(4, "Divya");
		hMap.put(5, "Jyoti");
		hMap.put(6, "Bharti");
		
//		for (Integer i : hMap.keySet()) {
//		      System.out.print(i + " ");
//		    }
//		System.out.println();
		
		for (HashMap.Entry m : hMap.entrySet()) {
			System.out.println(m.getKey()+" --- "+m.getValue());
		}
	}
}

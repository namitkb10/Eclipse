package java_Basic_Program;

public class Swapping_Using_Third_Variable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a=10, b=20, temp=0;
		
		System.out.println("A = " + a);
		System.out.println("B = " + b);
		
		temp=a;
		a=b;
		b=temp;
		
		System.out.println();
		
		System.out.println("A = " + a);
		System.out.println("B = " + b);
		
	}
}
